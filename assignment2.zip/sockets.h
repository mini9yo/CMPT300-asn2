#ifndef _SOCKETS_H
#define _SOCKETS_H

// Create socket
int createSocket(int PORT);

// Close socket
void closeSocket(int socketDescriptor);

#endif